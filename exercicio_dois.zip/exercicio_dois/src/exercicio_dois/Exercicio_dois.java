/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio_dois;

import java.util.Scanner;

/**
 *
 * @author dti
 */


/*Modificar o programa anterior para que
informe quantos alunos foram aprovados
e reprovados, ao final liste todas as
notas, a quantidade de aprovados e
reprovados, sendo que a média é 7.*/

public class Exercicio_dois {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        // TODO code application logic here
        
        int notas[] = new int[10];
        int i;
        int aprovado = 0;
        int reprovado = 0 ;
        
        Scanner in = new Scanner (System.in);
        
        System.out.println("Digite o valor das 10 notas em sequência");
        for(i = 0; i < 10; i++){
        notas[i] = in.nextInt();
        
          if(notas[i] < 7)
          {
            System.out.println("Este aluno está reprovado!");
            reprovado++;
          } 
          else 
          {
              System.out.println("Este aluno está aprovado!"); 
              aprovado++;
          }
        
          
        }
            System.out.println("A quantidade de aprovados é: " + aprovado + " e a quantidade de reprovados é: " + reprovado);
        
        
        
      
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio_um;

import java.util.Scanner;

/**
 *
 * @author dti
 */
public class Exercicio_um {

    
    /* Elaborar um programa que leia 10 notas
de alunos armazenando-as em um vetor
notas[ ], imprimir as notas de índice 7 e
9 no final.*/
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int notas[] = new int[10];
        int i;
        
        Scanner in = new Scanner (System.in);
        
        System.out.println("Digite o valor das 10 notas em sequência");
        for(i = 0; i < 10; i++){
        notas[i] = in.nextInt();
        }
        
        
        System.out.println("A nota do sétimo aluno é: " + notas[6] + " e a nota do nono aluno é: " + notas[8]);
        
        
    }
    
}
